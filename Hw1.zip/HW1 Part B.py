# Thomas Huang 26768493
import re
import os

def add_token(word: str, t_list: list)->list:
    if word not in t_list:
        t_list.append(word)
    return t_list

def tokenize(TextFilePath: str)->list:
    global text
    text = TextFilePath
    token_list = []
    with open(text) as f:
        lines = f.readlines()
    regex = "[A-Za-z0-9][A-Za-z0-9]*"
    for line in lines:
        for word in re.findall(regex, line):
            token_list = add_token(word.lower(), token_list)
    return token_list

def common(t_list1: list, t_list2: list)->list:
    c_list = []
    for item in t_list1:
        if item in t_list2:
            c_list.append(item)
    return c_list

def print_common(c_list: list):
    print("Common token(s):")
    for item in c_list:
        print("  " + str(item))
    print("Total of " + str(len(c_list)) + " common token(s).")

if __name__ == '__main__':

    file1 = ""
    file2 = ""
    while True:
        file1 = input("File 1 Name: ")
        if(os.path.isfile(file1)):
            break
        print("File does not exist.  Please enter an existing file name.")
    file2 = ""
    while True:
        file2 = input("File 2 Name: ")
        if(os.path.isfile(file2)):
            break
        print("File does not exist.  Please enter an existing file name.")
    t_list1 = tokenize(file1)
    t_list2 = tokenize(file2)

    c_list = common(t_list1, t_list2)
    print_common(c_list)
    
    print("\nRuntime complexity: O(n)")
